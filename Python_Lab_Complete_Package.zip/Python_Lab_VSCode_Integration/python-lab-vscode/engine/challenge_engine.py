
from __future__ import annotations
import json, random, subprocess, sys, textwrap, traceback, re
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PROGRESS=ROOT/'challenge_lab_progress.json'
BANK_SIZE=1_000_000

# A concept card contains: teaching notes, a task, a hint, a worked solution,
# a deterministic input generator, and a trusted reference implementation.
def P(name, topic, concept, learn, prompt, starter, hint, solution, gen, ref, why, kind='function'):
    return dict(name=name,topic=topic,concept=concept,learn=learn,prompt=prompt,
                starter=starter,hint=hint,solution=solution,gen=gen,ref=ref,why=why,kind=kind)

PATTERNS=[
P('Even or odd','Basics · numbers','Remainder and conditions',
  'The % operator gives a remainder. n % 2 is 0 for an even integer. A function should return a result; print is only for displaying it.',
  "Write solve(n) to return 'even' or 'odd'.",
  "def solve(n):\n    # Return the correct label.\n    pass",
  "Check n % 2 == 0, then return 'even'; otherwise return 'odd'.",
  "def solve(n):\n    return 'even' if n % 2 == 0 else 'odd'",
  lambda r:(r.randint(-100000,100000),),lambda a:'even' if a%2==0 else 'odd',
  'This also works for negative integers.'),
P('Sign classification','Basics · conditions','if / elif / else',
  'Comparisons such as > and < produce True or False. if/elif/else selects among cases.',
  "Write solve(n) to return 'positive', 'negative', or 'zero'.",
  "def solve(n):\n    pass",
  'Check n > 0, then n < 0; if neither applies, return zero.',
  "def solve(n):\n    if n > 0: return 'positive'\n    if n < 0: return 'negative'\n    return 'zero'",
  lambda r:(r.randint(-100000,100000),),lambda a:'positive' if a>0 else ('negative' if a<0 else 'zero'),
  'The three outcomes do not overlap.'),
P('Sum of digits','Loops · numbers','while, // and %',
  'n % 10 extracts the last digit; n // 10 removes it. Repeat until n becomes zero. The input is non-negative.',
  'Write solve(n) to return the sum of digits of a non-negative integer.',
  'def solve(n):\n    total = 0\n    # Extract digits one by one.\n    pass\n    return total',
  'While n > 0, add n % 10 and then set n //= 10. Zero should return zero.',
  'def solve(n):\n    total = 0\n    while n > 0:\n        total += n % 10\n        n //= 10\n    return total',
  lambda r:(r.randint(0,10**12),),lambda a:sum(map(int,str(a))),
  'This is a common loop and arithmetic pattern.'),
P('Factorial','Loops · numbers','Accumulator pattern',
  'Factorial n! multiplies 1 through n. An accumulator stores a running answer. By definition, 0! is 1.',
  'Write solve(n) to return factorial for 0 <= n <= 18.',
  'def solve(n):\n    result = 1\n    # Multiply by each integer from 2 through n.\n    pass\n    return result',
  'Use for i in range(2, n + 1): result *= i.',
  'def solve(n):\n    result = 1\n    for i in range(2, n + 1): result *= i\n    return result',
  lambda r:(r.randint(0,18),),lambda a:__import__('math').factorial(a),
  'Starting at 1 handles n=0 without a special case.'),
P('Count vowels','Strings','for loop, lower and membership',
  "Strings are sequences of characters. lower() normalizes capitalization; ch in 'aeiou' checks membership.",
  'Write solve(text) to count a, e, i, o, u regardless of case.',
  'def solve(text):\n    count = 0\n    # Inspect each character.\n    pass\n    return count',
  "Loop through text.lower(); if ch in 'aeiou', increment count.",
  "def solve(text):\n    count = 0\n    for ch in text.lower():\n        if ch in 'aeiou': count += 1\n    return count",
  lambda r:(''.join(r.choice('abCdeFGhI jKLMnoP! xyz') for _ in range(r.randint(0,70))),),
  lambda a:sum(ch in 'aeiou' for ch in a.lower()),'Repeated vowels count repeatedly; y is not included.'),
P('Reverse text','Strings','Slicing',
  'A slice is sequence[start:stop:step]. A step of -1 walks backward, so text[::-1] reverses a string.',
  'Write solve(text) to return text in reverse order.',
  'def solve(text):\n    pass',
  'Try the slice text[::-1].',
  'def solve(text):\n    return text[::-1]',
  lambda r:(''.join(r.choice('abc XYZ012!?é🙂') for _ in range(r.randint(0,55))),),
  lambda a:a[::-1],'Unicode text may contain multi-code-point emoji, but Python reverses code points.'),
P('Palindrome','Strings','Normalize then compare',
  'A palindrome reads the same backward. This task ignores capitalization, spaces and punctuation, retaining only letters and digits.',
  'Write solve(text) to return True if it is a palindrome under the rules above.',
  'def solve(text):\n    # Normalize, then compare with the reverse.\n    pass',
  "Build cleaned = ''.join(c.lower() for c in text if c.isalnum()); compare it to cleaned[::-1].",
  "def solve(text):\n    cleaned = ''.join(c.lower() for c in text if c.isalnum())\n    return cleaned == cleaned[::-1]",
  lambda r:(r.choice(['Never odd or even','A man, a plan, a canal: Panama','Python','No lemon, no melon','12321','','Was it a car or a cat I saw?']),),
  lambda a:(lambda s:s==s[::-1])(''.join(c.lower() for c in a if c.isalnum())),
  'An empty cleaned string is considered a palindrome here.'),
P('Normalize whitespace','Strings','split and join',
  'With no argument, split() separates runs of whitespace and removes leading/trailing whitespace. join() combines pieces.',
  'Write solve(text) to replace every whitespace run with one ordinary space and trim the ends.',
  'def solve(text):\n    pass',
  "Use ' '.join(text.split()).",
  "def solve(text):\n    return ' '.join(text.split())",
  lambda r:(''.join(r.choice(['a','b','c',' ',' ','\\t','\n']) for _ in range(r.randint(0,60))),),
  lambda a:' '.join(a.split()),'This handles spaces, tabs and newlines.'),
P('Maximum without max','Lists','Iteration and boundaries',
  'A list stores ordered values. Start with the first item, then replace the current largest when you find a bigger value. Input is non-empty.',
  'Write solve(values) to return the largest integer without using max().',
  'def solve(values):\n    largest = values[0]\n    # Compare each item.\n    pass\n    return largest',
  'Loop over values; if item > largest, update largest.',
  'def solve(values):\n    largest = values[0]\n    for item in values:\n        if item > largest: largest = item\n    return largest',
  lambda r:([r.randint(-10000,10000) for _ in range(r.randint(1,35))],),
  lambda a:max(a),'Starting with the first value works for all-negative lists.'),
P('Stable deduplication','Lists · sets','Membership and order',
  'A set is useful for fast membership checks. Keep a separate list to preserve the first-seen order.',
  'Write solve(values) to remove duplicate integers while preserving first occurrences.',
  'def solve(values):\n    seen, result = set(), []\n    # Add only unseen values.\n    pass\n    return result',
  'If item not in seen, add it to seen and append it to result.',
  'def solve(values):\n    seen, result = set(), []\n    for item in values:\n        if item not in seen:\n            seen.add(item); result.append(item)\n    return result',
  lambda r:([r.randint(-12,12) for _ in range(r.randint(0,45))],),
  lambda a:list(dict.fromkeys(a)),'A set alone is not the right output because order matters.'),
P('Second-largest distinct','Lists · algorithms','Track two best values',
  'The second-largest DISTINCT value must differ from the largest. This task bans sorting so you practise one-pass tracking.',
  'Write solve(values) to return the second-largest distinct integer. At least two distinct values exist.',
  'def solve(values):\n    largest = second = None\n    # Track two distinct values.\n    pass\n    return second',
  'When x is a new largest, move the old largest into second. Otherwise update second only when x is distinct and larger than it.',
  'def solve(values):\n    largest = second = None\n    for x in values:\n        if largest is None or x > largest:\n            second, largest = largest, x\n        elif x != largest and (second is None or x > second):\n            second = x\n    return second',
  lambda r:(r.sample(range(-10000,10001),r.randint(2,25)),),
  lambda a:sorted(set(a))[-2],'Duplicate maximum values do not count as the second-largest distinct value.'),
P('Rotate list right','Lists · slicing','Modulo and edge cases',
  'A right rotation moves the final k items to the front. k % len(values) reduces large rotations. Empty lists need special handling.',
  'Write solve(data), where data is (values, k), to rotate right by k. Empty input returns [].',
  'def solve(data):\n    values, k = data\n    # Return a rotated copy.\n    pass',
  'Handle empty values; reduce k modulo length; for k=0 return a copy; otherwise combine values[-k:] and values[:-k].',
  'def solve(data):\n    values, k = data\n    if not values: return []\n    k %= len(values)\n    if k == 0: return values[:]\n    return values[-k:] + values[:-k]',
  lambda r:(([r.randint(-20,20) for _ in range(r.randint(0,20))],r.randint(0,60)),),
  lambda d:(lambda a,k:(a[-(k%len(a)):]+a[:-(k%len(a))]) if a and k%len(a) else a[:])(d[0],d[1]),
  'A zero rotation should return all items in their original order.'),
P('Frequency dictionary','Dictionaries','Counting with dict.get',
  'A dictionary maps keys to values. counts.get(x, 0) gives the old count or zero if the key is missing.',
  'Write solve(values) to return a dictionary mapping each integer to its occurrence count.',
  'def solve(values):\n    counts = {}\n    # Count each item.\n    pass\n    return counts',
  'For each item, assign counts[item] = counts.get(item, 0) + 1.',
  'def solve(values):\n    counts = {}\n    for item in values: counts[item] = counts.get(item, 0) + 1\n    return counts',
  lambda r:([r.randint(-8,8) for _ in range(r.randint(0,35))],),
  lambda a:{v:a.count(v) for v in set(a)},'Dictionary equality does not depend on insertion order.'),
P('Group by parity','Dictionaries · grouping','Dictionary of lists',
  'Grouping collects related values under a key. The lists should keep input order and both keys should exist.',
  "Write solve(values) to return {'even': [...], 'odd': [...]} preserving order.",
  "def solve(values):\n    result = {'even': [], 'odd': []}\n    # Choose a group and append.\n    pass\n    return result",
  "key = 'even' if x % 2 == 0 else 'odd'; append x to result[key].",
  "def solve(values):\n    result = {'even': [], 'odd': []}\n    for x in values:\n        key = 'even' if x % 2 == 0 else 'odd'\n        result[key].append(x)\n    return result",
  lambda r:([r.randint(-99,99) for _ in range(r.randint(0,35))],),
  lambda a:{'even':[x for x in a if x%2==0],'odd':[x for x in a if x%2!=0]},
  'Both dictionary keys must exist even if their lists are empty.'),
P('Anagram check','Strings · sorting','Character counts and normalization',
  'Anagrams contain the same letters with the same counts in a different order. This version ignores spaces and capitalization.',
  'Write solve(pair), where pair=(a,b), returning True if they are anagrams ignoring spaces and case.',
  'def solve(pair):\n    a, b = pair\n    # Normalize and compare.\n    pass',
  "Normalize with ''.join(s.lower().split()), then compare the sorted characters.",
  "def solve(pair):\n    a, b = pair\n    a = ''.join(a.lower().split()); b = ''.join(b.lower().split())\n    return sorted(a) == sorted(b)",
  lambda r:(r.choice([('listen','silent'),('Dormitory','Dirty room'),('hello','world'),('aab','aba'),('',''),('python','typhon'),('evil','vile')]),),
  lambda d:sorted(''.join(d[0].lower().split()))==sorted(''.join(d[1].lower().split())),
  'Punctuation is not ignored by this definition.'),
P('Prime number','Loops · algorithms','Divisors and square-root bound',
  'A prime is an integer greater than 1 with no positive divisors other than 1 and itself. Testing divisors only through sqrt(n) is enough.',
  'Write solve(n) to return True if n is prime, otherwise False. Inputs range from -10 to 100000.',
  'def solve(n):\n    if n < 2: return False\n    # Test possible divisors.\n    pass',
  'Try d from 2 while d*d <= n. If n % d == 0, return False. Otherwise return True.',
  'def solve(n):\n    if n < 2: return False\n    d = 2\n    while d*d <= n:\n        if n % d == 0: return False\n        d += 1\n    return True',
  lambda r:(r.randint(-10,100000),),
  lambda n:n>=2 and all(n%d for d in range(2,int(n**0.5)+1)),
  '0, 1 and negative integers are not prime.'),
P('Fibonacci','Loops · sequences','State updates',
  'Fibonacci starts 0, 1, 1, 2, 3, 5... Each new term is the sum of the previous two. Update both variables at once.',
  'Write solve(n) to return F(n), with F(0)=0 and F(1)=1; 0 <= n <= 500.',
  'def solve(n):\n    a, b = 0, 1\n    # Repeat n updates.\n    pass\n    return a',
  'Repeat n times: a, b = b, a + b. Then return a.',
  'def solve(n):\n    a, b = 0, 1\n    for _ in range(n): a, b = b, a+b\n    return a',
  lambda r:(r.randint(0,500),),
  lambda n:(lambda ab:ab[0])(__import__('functools').reduce(lambda ab,_:(ab[1],ab[0]+ab[1]),range(n),(0,1))),
  'The underscore _ is a conventional name for an unused loop value.'),
P('Flatten one level','Nested lists','Nested loops',
  'Flattening one level copies each item from each inner list into one output list. It does not recursively flatten deeper nested structures.',
  'Write solve(groups) to flatten exactly one level of a list of lists.',
  'def solve(groups):\n    result = []\n    # Use a loop inside a loop.\n    pass\n    return result',
  'For each group, loop through its items and append each item.',
  'def solve(groups):\n    result = []\n    for group in groups:\n        for item in group: result.append(item)\n    return result',
  lambda r:([[r.randint(-9,9) for _ in range(r.randint(0,8))] for _ in range(r.randint(0,10))],),
  lambda a:[v for group in a for v in group],'Both the group order and item order are preserved.'),
P('Word frequency','Strings · dictionaries','split, strip and counting',
  'split() separates words on whitespace. lower() normalizes case. strip(string.punctuation) removes punctuation at word edges.',
  'Write solve(text) to return word frequencies, ignoring case and stripping punctuation from each word edge.',
  "import string\ndef solve(text):\n    counts = {}\n    # Normalize and count words.\n    pass\n    return counts",
  'Loop over text.lower().split(); strip string.punctuation; skip empty results; increment counts.',
  "import string\ndef solve(text):\n    counts = {}\n    for word in text.lower().split():\n        word = word.strip(string.punctuation)\n        if word: counts[word] = counts.get(word, 0) + 1\n    return counts",
  lambda r:(r.choice(['Data data DATA!','Python, is fun; python is useful.','... hello hello!','One-two one-two','','SQL + Python, Python.']),),
  lambda s:(lambda ws:{w:ws.count(w) for w in set(ws)})([w for raw in s.lower().split() if (w:=raw.strip(__import__('string').punctuation))]),
  'This is a teaching-sized tokenizer, not a full natural-language processor.'),
P('Safe division','Functions · validation','Invalid inputs',
  'Functions should define invalid-input behavior. Checking a denominator before dividing avoids an expected ZeroDivisionError.',
  "Write solve(pair) for (a,b): return a/b, or 'cannot divide by zero' if b is zero.",
  'def solve(pair):\n    a, b = pair\n    # Handle the zero denominator.\n    pass',
  "If b == 0, return the exact message; otherwise return a / b.",
  "def solve(pair):\n    a, b = pair\n    if b == 0: return 'cannot divide by zero'\n    return a/b",
  lambda r:((r.randint(-100,100),r.randint(-20,20)),),
  lambda d:'cannot divide by zero' if d[1]==0 else d[0]/d[1],
  'The message must match exactly, including spaces.'),
P('Simple email-like validation','Functions · validation','String checks and early returns',
  'Validation checks data against stated rules. This is deliberately a simple rule, not complete validation for real email addresses.',
  "Write solve(text): return True if there is exactly one '@', non-empty text before it, and a dot in the part after it.",
  'def solve(text):\n    # Apply each rule.\n    pass',
  "Check count('@') == 1; split at @; require both parts and '.' in the right part.",
  "def solve(text):\n    if text.count('@') != 1: return False\n    left, right = text.split('@')\n    return bool(left and right and '.' in right)",
  lambda r:(r.choice(['a@b.com','@b.com','a@','a@b','a@b.c','a@@b.com','x@y.z','','name+tag@example.org']),),
  lambda s:s.count('@')==1 and bool(s.split('@')[0]) and bool(s.split('@')[1]) and '.' in s.split('@')[1],
  'Always follow the exact rules in the prompt instead of assuming a broader standard.'),
P('Binary search','Algorithms · searching','Sorted input and shrinking bounds',
  'Binary search repeatedly halves a sorted search range. It is O(log n), but only works if the input is sorted.',
  'Write solve(data), data=(sorted_values,target), returning the target index or -1. Do not use index() or in.',
  'def solve(data):\n    values, target = data\n    left, right = 0, len(values)-1\n    # Shrink the search interval.\n    pass\n    return -1',
  'Calculate mid=(left+right)//2. If too small, move left; otherwise move right.',
  'def solve(data):\n    values, target = data\n    left, right = 0, len(values)-1\n    while left <= right:\n        mid = (left+right)//2\n        if values[mid] == target: return mid\n        if values[mid] < target: left = mid+1\n        else: right = mid-1\n    return -1',
  lambda r:((lambda a:(a,r.randint(-120,120)))(sorted(r.sample(range(-100,101),r.randint(0,45)))),),
  lambda d:d[0].index(d[1]) if d[1] in d[0] else -1,
  'The generated sorted lists contain distinct integers.'),
P('Two sum','Algorithms · hash maps','Complement lookup',
  'For each x, the needed partner is target-x. A dictionary remembers values seen earlier, making lookup fast and avoiding using the same index twice.',
  'Write solve(data) where data=(values,target). Return [i,j] for the first pair scanning left to right, or [] if none.',
  'def solve(data):\n    values, target = data\n    seen = {}\n    # Find a complement before storing current value.\n    pass\n    return []',
  'For each index i and value x, check whether target-x is in seen. If yes, return its index and i.',
  'def solve(data):\n    values, target = data\n    seen = {}\n    for i, x in enumerate(values):\n        need = target-x\n        if need in seen: return [seen[need], i]\n        if x not in seen: seen[x] = i\n    return []',
  lambda r:(([r.randint(-30,30) for _ in range(r.randint(0,24))],r.randint(-50,50)),),
  lambda d:next(([i,j] for i in range(len(d[0])) for j in range(i+1,len(d[0])) if d[0][i]+d[0][j]==d[1]),[]),
  'This trades extra memory for faster lookup.'),
P('Chunk a list','Lists · iteration','range step and slicing',
  'Chunking splits a list into consecutive groups. range(0,len(items),size) visits each chunk start.',
  'Write solve(data), data=(items,size), returning chunks; the last may be shorter. size is positive.',
  'def solve(data):\n    items, size = data\n    result = []\n    # Move forward by size.\n    pass\n    return result',
  'For start in range(0,len(items),size), append items[start:start+size].',
  'def solve(data):\n    items, size = data\n    return [items[i:i+size] for i in range(0,len(items),size)]',
  lambda r:(([r.randint(-50,50) for _ in range(r.randint(0,50))],r.randint(1,10)),),
  lambda d:[d[0][i:i+d[1]] for i in range(0,len(d[0]),d[1])],
  'Slicing stops safely at the end of a list.'),
P('Transpose matrix','Nested data · matrices','Rows and columns',
  'Transposing swaps rows and columns: matrix[r][c] becomes output[c][r]. This challenge defines an empty matrix as [].',
  'Write solve(matrix) to return its transpose.',
  'def solve(matrix):\n    if not matrix: return []\n    # Swap row and column positions.\n    pass',
  'For each column c, collect row[c] for every row.',
  'def solve(matrix):\n    if not matrix: return []\n    return [[row[c] for row in matrix] for c in range(len(matrix[0]))]',
  lambda r:((lambda rows,cols:[[r.randint(-9,9) for _ in range(cols)] for _ in range(rows)])(r.randint(0,8),r.randint(0,8)),),
  lambda a:[] if not a else [[row[c] for row in a] for c in range(len(a[0]))],
  'Input matrices are rectangular; a matrix with zero rows is defined as [].'),
P('Recursive sum','Recursion','Base case and recursive step',
  'A recursive function calls itself on a smaller problem. It needs a base case. Here the sum of an empty list is 0.',
  'Write solve(values) to sum integers recursively. Do not use sum().',
  'def solve(values):\n    if not values: return 0\n    # First item plus the rest.\n    pass',
  'Return values[0] + solve(values[1:]).',
  'def solve(values):\n    if not values: return 0\n    return values[0] + solve(values[1:])',
  lambda r:([r.randint(-20,20) for _ in range(r.randint(0,14))],),
  lambda a:sum(a),'Recursion is useful for learning; loops handle very long lists more safely.'),
P('List comprehension','Pythonic code','Mapping and filtering',
  'A comprehension builds a list: [expression for item in iterable if condition]. It replaces a loop and append.',
  'Write solve(values) to return squares of even integers only, preserving order.',
  'def solve(values):\n    # Filter even values and square them.\n    pass',
  'Use [x*x for x in values if x % 2 == 0].',
  'def solve(values):\n    return [x*x for x in values if x%2==0]',
  lambda r:([r.randint(-100,100) for _ in range(r.randint(0,40))],),
  lambda a:[x*x for x in a if x%2==0],'Negative even numbers are even too.'),
P('Set operations','Sets','Union, intersection and difference',
  'Sets hold unique values. | is union, & intersection, and - difference. Sorted lists make results deterministic.',
  "Write solve(pair) for (a,b), returning keys 'union', 'intersection', and 'left_only', each a sorted list.",
  'def solve(pair):\n    a, b = map(set, pair)\n    # Return the three set operations.\n    pass',
  "Return sorted(a|b), sorted(a&b), and sorted(a-b) under the required keys.",
  "def solve(pair):\n    a, b = map(set, pair)\n    return {'union':sorted(a|b),'intersection':sorted(a&b),'left_only':sorted(a-b)}",
  lambda r:((r.sample(range(-30,31),r.randint(0,18)),r.sample(range(-30,31),r.randint(0,18))),),
  lambda d:{'union':sorted(set(d[0])|set(d[1])),'intersection':sorted(set(d[0])&set(d[1])),'left_only':sorted(set(d[0])-set(d[1]))},
  'Sorting the results makes output order predictable.'),
P('Class with state','OOP · classes','class, __init__, self',
  'A class defines objects. __init__ initializes each object. self refers to the current instance. State belongs to each instance.',
  'Define class Counter with __init__(self,start=0), increment(self) adding one, and value(self) returning the count.',
  'class Counter:\n    def __init__(self, start=0):\n        self.count = start\n    def increment(self):\n        # Add one.\n        pass\n    def value(self):\n        # Return the count.\n        pass',
  'Use self.count += 1 inside increment; return self.count inside value. Do not print.',
  'class Counter:\n    def __init__(self, start=0): self.count = start\n    def increment(self): self.count += 1\n    def value(self): return self.count',
  lambda r:(r.randint(-100,100),),lambda a:a,'The checker creates an instance and calls increment several times.', 'class'),
P('Class validation','OOP · classes','Validation and object invariants',
  'Encapsulation groups state and behavior. Validate at the boundary so invalid operations cannot corrupt the object.',
  'Define BankAccount(balance=0) with deposit(amount) and get_balance(). deposit raises ValueError for amount <= 0.',
  'class BankAccount:\n    def __init__(self, balance=0): self.balance = balance\n    def deposit(self, amount):\n        # Reject invalid deposits.\n        pass\n    def get_balance(self):\n        pass',
  "If amount <= 0, raise ValueError. Otherwise add it to self.balance. get_balance returns the balance.",
  "class BankAccount:\n    def __init__(self, balance=0): self.balance = balance\n    def deposit(self, amount):\n        if amount <= 0: raise ValueError('amount must be positive')\n        self.balance += amount\n    def get_balance(self): return self.balance",
  lambda r:(r.randint(0,10000),),lambda a:a,'The checker tests a valid deposit and that zero is rejected.', 'bank'),
P('Sort records','Functions · sorting','key functions and tie-breakers',
  'sorted(items,key=...) sorts by a calculated key. A tuple key handles a primary key and a tie-breaker.',
  "Write solve(records) to sort dictionaries by score descending, then name ascending.",
  'def solve(records):\n    # Return the sorted records.\n    pass',
  "Use sorted(records, key=lambda r: (-r['score'], r['name'])).",
  "def solve(records):\n    return sorted(records, key=lambda r:(-r['score'],r['name']))",
  lambda r:([{'name':n,'score':r.randint(0,100)} for n in r.sample(['Ava','Ben','Cleo','Dev','Eli','Fay','Gus','Hana'],r.randint(0,8))],),
  lambda a:sorted(a,key=lambda x:(-x['score'],x['name'])),'Negating the score makes numeric sorting descending.'),
P('Generator and all','Iterators · generators','Lazy values and all()',
  'A generator expression produces values one at a time. all(...) is True only when every condition is true; all([]) is True.',
  'Write solve(values) to return True if every value is positive, otherwise False.',
  'def solve(values):\n    pass',
  'Return all(x > 0 for x in values).',
  'def solve(values):\n    return all(x > 0 for x in values)',
  lambda r:([r.randint(-5,10) for _ in range(r.randint(0,25))],),
  lambda a:all(x>0 for x in a),'The empty-list result follows the mathematical convention for all().'),
P('Convert safely','Exceptions · conversion','try / except ValueError',
  'int(text) converts integer text. Invalid text raises ValueError; try/except handles this expected failure.',
  'Write solve(text) to return int(text) when valid, otherwise None. Whitespace around an integer is allowed.',
  'def solve(text):\n    try:\n        # Convert to int.\n        pass\n    except ValueError:\n        return None',
  'Return int(text) inside try. Return None in except ValueError.',
  'def solve(text):\n    try: return int(text)\n    except ValueError: return None',
  lambda r:(r.choice(['12',' -7 ','0','','4.2','abc','+25','1_000','--1']),),
  lambda s:(int(s) if s.strip() in ['12','-7','0','+25','1_000'] else None),
  'This generator uses a known set of valid and invalid examples.'),
]

# Applied / interview-style challenge pack. These are intentionally not syntax drills.
PATTERNS.extend([
P('API retry schedule','Production engineering · resilience','Exponential backoff with a cap',
  'Retry schedules should grow to reduce load during outages, but a cap prevents impractically long waits. This challenge returns delays only; it does not sleep.',
  'Given (attempts, base, cap), return one delay per retry using base * 2**retry_index, capped at cap. attempts may be zero.',
  'def solve(config):\n    attempts, base, cap = config\n    # Return the planned delays.\n    pass',
  'Build a list for retry indexes from 0 to attempts-1 and apply min(cap, base * 2**i).',
  'def solve(config):\n    attempts, base, cap = config\n    return [min(cap, base * (2 ** i)) for i in range(attempts)]',
  lambda r:((r.randint(0,9),r.randint(1,5),r.randint(8,1000)),),
  lambda a:[min(a[2],a[1]*(2**i)) for i in range(a[0])],
  'Useful for API clients and background workers; real systems often add jitter.'),
P('Log severity aggregation','Observability · log analysis','Counter and threshold classification',
  'Logs often arrive as event records. Aggregating counts by severity turns raw events into an operational summary.',
  "Given a list of log dictionaries with a 'level' field, return counts for ERROR, WARN, INFO, and OTHER. Matching is case-insensitive.",
  "def solve(logs):\n    # Return a dictionary with ERROR, WARN, INFO, OTHER.\n    pass",
  "Normalize each level with .upper(), then increment one of the four buckets.",
  "def solve(logs):\n    counts = {'ERROR': 0, 'WARN': 0, 'INFO': 0, 'OTHER': 0}\n    for row in logs:\n        level = str(row.get('level', '')).upper()\n        key = level if level in ('ERROR', 'WARN', 'INFO') else 'OTHER'\n        counts[key] += 1\n    return counts",
  lambda r:([{'level':r.choice(['error','WARN','info','debug','trace',''])} for _ in range(r.randint(0,35))],),
  lambda a:{k:sum(1 for x in a if (str(x.get('level','')).upper() if str(x.get('level','')).upper() in ('ERROR','WARN','INFO') else 'OTHER')==k) for k in ('ERROR','WARN','INFO','OTHER')},
  'A common first step in incident triage and dashboard preparation.'),
P('Deduplicate events by key','Data pipelines · records','Stable deduplication',
  'Event feeds may contain repeated deliveries. Keeping the first event per ID preserves the original arrival order and is often required for idempotent processing.',
  "Given event dictionaries, return only the first event for each 'id'. Events without an id are treated as unique and retained.",
  "def solve(events):\n    # Preserve order; don't mutate the input.\n    pass",
  "Track IDs already seen. For missing IDs, retain the event without adding a shared sentinel to the seen set.",
  "def solve(events):\n    seen, result = set(), []\n    for event in events:\n        if 'id' not in event or event['id'] not in seen:\n            result.append(event)\n            if 'id' in event: seen.add(event['id'])\n    return result",
  lambda r:([({'id':r.choice([None,1,2,3,4,5]),'value':r.randint(0,99)} if r.random()>.12 else {'value':r.randint(0,99)}) for _ in range(r.randint(0,30))],),
  lambda a:(lambda:None)() if False else _dedupe_reference(a),
  'This pattern helps make ingestion jobs repeatable.'),
P('CSV row validation','Data quality · validation','Collect errors instead of failing fast',
  'A robust data import should report every bad row so a user can repair a file in one pass. Validation and conversion should be explicit.',
  "Given rows as dictionaries with 'email' and 'age', return the zero-based indexes of rows where email lacks '@' or age cannot be converted to an integer >= 0.",
  'def solve(rows):\n    # Return invalid row indexes.\n    pass',
  "Use enumerate. Validate email and convert age inside try/except (TypeError, ValueError).",
  "def solve(rows):\n    bad = []\n    for i, row in enumerate(rows):\n        email = str(row.get('email', ''))\n        try: age = int(row.get('age'))\n        except (TypeError, ValueError): age = -1\n        if '@' not in email or age < 0: bad.append(i)\n    return bad",
  lambda r:([{'email':r.choice(['a@b.com','bad','x@y','']), 'age':r.choice([str(r.randint(0,99)),None,'NaN',-1])} for _ in range(r.randint(0,25))],),
  lambda rows:[i for i,row in enumerate(rows) if '@' not in str(row.get('email','')) or not _valid_age(row.get('age'))],
  'Useful in ETL pipelines and pre-ingestion checks.'),
P('Top-k slow endpoints','Performance analysis · aggregation','Dictionary aggregation and heap selection',
  'Monitoring data often contains many measurements per endpoint. Aggregate first, then rank by average latency and use a stable tie-breaker.',
  "Given records with 'endpoint' and 'ms', return up to k endpoints as (endpoint, average_ms) pairs, sorted by average descending then endpoint ascending. Ignore records with invalid or negative ms.",
  'def solve(data):\n    records, k = data\n    # Aggregate valid measurements, then rank.\n    pass',
  'Use total/count dictionaries. Compute averages only for endpoints with valid measurements; sort by (-average, endpoint).',
  "def solve(data):\n    records, k = data\n    totals, counts = {}, {}\n    for row in records:\n        try: ms = float(row['ms'])\n        except (KeyError, TypeError, ValueError): continue\n        if ms < 0: continue\n        name = str(row.get('endpoint', ''))\n        totals[name] = totals.get(name, 0.0) + ms\n        counts[name] = counts.get(name, 0) + 1\n    ranked = [(name, totals[name] / counts[name]) for name in totals]\n    ranked.sort(key=lambda x: (-x[1], x[0]))\n    return ranked[:max(0, k)]",
  lambda r:(([{'endpoint':r.choice(['/api/users','/api/orders','/health','/search']), 'ms':r.choice([r.random()*800,-1,'bad',None])} for _ in range(r.randint(0,35))],r.randint(0,5)),),
  lambda data:_top_endpoints(data),
  'This combines parsing, defensive validation, aggregation, and deterministic ranking.'),
P('Interval overlap detection','Scheduling · intervals','Half-open interval semantics',
  'Scheduling systems often use half-open intervals [start, end), so adjacent bookings ending and starting at the same time do not overlap.',
  'Given a list of (start, end) intervals, return True if any valid intervals overlap. Ignore intervals where start >= end.',
  'def solve(intervals):\n    # Detect overlap without treating adjacent intervals as overlapping.\n    pass',
  'Sort valid intervals by start; an overlap exists when the next start is strictly less than the previous end.',
  'def solve(intervals):\n    valid = sorted((a,b) for a,b in intervals if a < b)\n    return any(valid[i][0] < valid[i-1][1] for i in range(1, len(valid)))',
  lambda r:([(a:=r.randint(0,40),a+r.randint(-2,12)) for _ in range(r.randint(0,20))],),
  lambda intervals:(lambda v:any(v[i][0]<v[i-1][1] for i in range(1,len(v))))(sorted((a,b) for a,b in intervals if a<b)),
  'Correct interval semantics prevent false conflicts in calendars and reservation systems.'),
P('Configuration precedence','Application configuration · dictionaries','Layered merge precedence',
  'Applications commonly combine defaults, environment values, and explicit overrides. Later layers take precedence while unrelated keys remain intact.',
  'Given (defaults, environment, overrides), return a new dictionary merged in that order. Do not mutate any input.',
  'def solve(layers):\n    defaults, environment, overrides = layers\n    # Merge from lowest to highest precedence.\n    pass',
  'Copy defaults first, then update with environment and overrides.',
  'def solve(layers):\n    defaults, environment, overrides = layers\n    result = dict(defaults)\n    result.update(environment)\n    result.update(overrides)\n    return result',
  lambda r:(({f'k{i}':r.randint(0,9) for i in range(5)}, {f'k{i}':r.randint(0,9) for i in range(2,7)}, {f'k{i}':r.randint(0,9) for i in range(4,9)}),),
  lambda x:{**x[0],**x[1],**x[2]},
  'This is the same precedence principle used by many app settings systems.'),
P('Batch records by size','Data engineering · batching','Chunking and boundary handling',
  'Batching lets a pipeline send bounded requests. The final batch may be smaller than the requested size; invalid batch sizes should be rejected.',
  'Given (items, size), return consecutive batches of at most size items. Raise ValueError when size <= 0.',
  'def solve(data):\n    items, size = data\n    # Return a list of batches.\n    pass',
  'Validate size, then slice items in steps of size.',
  'def solve(data):\n    items, size = data\n    if size <= 0: raise ValueError("size must be positive")\n    return [items[i:i+size] for i in range(0, len(items), size)]',
  lambda r:((list(range(r.randint(0,60))),r.randint(1,12)),),
  lambda data:[data[0][i:i+data[1]] for i in range(0,len(data[0]),data[1])],
  'Useful for API pagination, database writes, and ETL jobs.'),
P('Parse duration strings','Data ingestion · parsing','Regular expressions and defensive parsing',
  'Operational metrics often arrive as strings. A parser should accept only a documented grammar and return a predictable numeric representation.',
  "Parse strings like '250ms', '1.5s', and '2m' into milliseconds. Units are case-insensitive; invalid input returns None.",
  'def solve(text):\n    # Return milliseconds or None.\n    pass',
  'Use a full-match regular expression for a number and unit, then multiply by the unit scale.',
  "def solve(text):\n    import re\n    m = re.fullmatch(r'\\s*(\\d+(?:\\.\\d+)?)\\s*(ms|s|m)\\s*', str(text), re.I)\n    if not m: return None\n    scale = {'ms': 1, 's': 1000, 'm': 60000}[m.group(2).lower()]\n    return float(m.group(1)) * scale",
  lambda r:(r.choice([f'{r.randint(0,500)}ms',f'{r.randint(1,99)/10}s',f'{r.randint(1,20)}m','n/a','3 hours','']),),
  lambda text:_duration_ms(text),
  'A realistic parsing task: validate the complete input, not just a matching substring.'),
P('Rolling average','Time series · streaming data','Sliding window with a running sum',
  'A rolling average smooths noisy metrics. Maintaining a running sum avoids recomputing every window from scratch.',
  'Given (values, window), return the average for every full window. If window <= 0 raise ValueError; if window exceeds input length return an empty list.',
  'def solve(data):\n    values, window = data\n    # Return rolling averages.\n    pass',
  'Compute the first window sum, then add the incoming value and subtract the outgoing value.',
  'def solve(data):\n    values, window = data\n    if window <= 0: raise ValueError("window must be positive")\n    if window > len(values): return []\n    total = sum(values[:window])\n    out = [round(total / window, 8)]\n    for i in range(window, len(values)):\n        total += values[i] - values[i-window]\n        out.append(round(total / window, 8))\n    return out',
  lambda r:(([r.randint(-100,500)/10 for _ in range(r.randint(0,40))],r.randint(1,10)),),
  lambda data:[round(sum(data[0][i:i+data[1]])/data[1],8) for i in range(len(data[0])-data[1]+1)],
  'Common in telemetry, finance, and trend monitoring.'),
])

def _dedupe_reference(events):
    seen, out = set(), []
    for e in events:
        if 'id' not in e or e['id'] not in seen:
            out.append(e)
            if 'id' in e: seen.add(e['id'])
    return out

def _valid_age(value):
    try: return int(value) >= 0
    except (TypeError, ValueError): return False

def _top_endpoints(data):
    records, k = data
    totals, counts = {}, {}
    for row in records:
        try: ms = float(row['ms'])
        except (KeyError, TypeError, ValueError): continue
        if ms < 0: continue
        name = str(row.get('endpoint', ''))
        totals[name] = totals.get(name, 0.0) + ms
        counts[name] = counts.get(name, 0) + 1
    return sorted([(n, totals[n]/counts[n]) for n in totals], key=lambda x:(-x[1],x[0]))[:max(0,k)]

def _duration_ms(text):
    m = re.fullmatch(r'\s*(\d+(?:\.\d+)?)\s*(ms|s|m)\s*', str(text), re.I)
    if not m: return None
    return float(m.group(1)) * {'ms':1,'s':1000,'m':60000}[m.group(2).lower()]

ADVANCED_PATTERNS = PATTERNS[-10:]

def challenge(i):
    i=max(0,min(BANK_SIZE-1,int(i)))
    pi=i%len(ADVANCED_PATTERNS); seed=i//len(ADVANCED_PATTERNS)+17; p=ADVANCED_PATTERNS[pi]
    r=random.Random(seed*1009+pi)
    arg=p['gen'](r)[0]
    cases=[arg]+[p['gen'](random.Random(seed*7919+j*97+pi))[0] for j in range(1,6)]
    return {'id':i,'pattern':p,'arg':arg,'cases':cases,'seed':seed}

def expected(p,arg):
    if p['kind']=='class': return arg+(abs(arg)%5+1)
    if p['kind']=='bank': return arg+7
    return p['ref'](arg)


def cli_main():
    if len(sys.argv) < 3 or sys.argv[1] != '--cli':
        print(json.dumps({'error':'Usage: --cli challenge|hint|solution|check|run <id> [source]'})); return 2
    action=sys.argv[2]
    idx=int(sys.argv[3]) if len(sys.argv)>3 else 0
    if action=='catalog':
        rows=[]
        for i,pat in enumerate(ADVANCED_PATTERNS):
            rows.append({'id':i,'name':pat['name'],'topic':pat['topic'],'concept':pat['concept'],'level':('Advanced' if any(k in (pat['topic']+' '+pat['concept']).lower() for k in ('production','data engineer','performance','time series','observability','resilience','scheduling','data quality','application configuration','data pipeline','parsing')) else 'Intermediate'),'keywords':' '.join([pat['name'],pat['topic'],pat['concept'],pat['learn'],pat['prompt']])})
        print(json.dumps({'patterns':rows,'bank_size':BANK_SIZE,'pattern_count':len(ADVANCED_PATTERNS)},ensure_ascii=False)); return 0
    ch=challenge(idx); p=ch['pattern']
    if action=='challenge':
        out={'id':ch['id'],'bank_size':BANK_SIZE,'pattern':{k:v for k,v in p.items() if k not in ('gen','ref')},'arg':ch['arg'],'cases':ch['cases'],'expected_cases':[expected(p,c) for c in ch['cases']]}
        print(json.dumps(out,ensure_ascii=False)); return 0
    if action=='hint': print(json.dumps({'hint':p['hint']},ensure_ascii=False)); return 0
    if action=='solution': print(json.dumps({'solution':p['solution']},ensure_ascii=False)); return 0
    source=sys.stdin.read()
    if action not in ('check','run'):
        print(json.dumps({'error':'Unknown action'})); return 2
    if action=='run':
        if p['kind']=='class': harness=f"obj=Counter({ch['arg']!r})\nfor _ in range(abs({ch['arg']!r})%5+1): obj.increment()\nprint(repr(obj.value()))"
        elif p['kind']=='bank': harness=f"obj=BankAccount({ch['arg']!r})\nobj.deposit(7)\nprint(repr(obj.get_balance()))"
        else: harness=f"print(repr(solve({ch['arg']!r})))"
        payload=f"import math, string, itertools, functools, collections, re\nexec({source!r},globals(),globals())\n{harness}"
        try:
            proc=subprocess.run([sys.executable,'-X','utf8','-c',payload],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=3)
            print(json.dumps({'returncode':proc.returncode,'stdout':proc.stdout[-5000:],'stderr':proc.stderr[-5000:]},ensure_ascii=False)); return 0
        except subprocess.TimeoutExpired:
            print(json.dumps({'returncode':124,'stdout':'','stderr':'Time limit exceeded (3 seconds).'})); return 0
    expected_values=[expected(p,c) for c in ch['cases']]
    if p['kind']=='class': body="obj=Counter(case)\nfor _ in range(abs(case)%5+1): obj.increment()\ngot=obj.value()"
    elif p['kind']=='bank': body="obj=BankAccount(case)\nobj.deposit(7)\ngot=obj.get_balance()\ntry:\n obj.deposit(0); invalid=False\nexcept ValueError:\n invalid=True\nif not invalid: raise AssertionError('deposit(0) must raise ValueError')"
    else: body='got=solve(case)'
    payload=f"import json, math, string, itertools, functools, collections, re\nexec({source!r},globals(),globals())\nCASES={ch['cases']!r}\nEXPECTED={expected_values!r}\nresults=[]\nfor n,case in enumerate(CASES,1):\n got=None\n try:\n{textwrap.indent(body,'  ')}\n  want=EXPECTED[n-1]\n  if got != want: raise AssertionError('expected '+repr(want)+', got '+repr(got))\n  results.append((True,repr(case),repr(want),repr(got),'PASS'))\n except Exception as e: results.append((False,repr(case),repr(EXPECTED[n-1]),repr(got),type(e).__name__+': '+str(e)))\nprint(json.dumps(results,ensure_ascii=False))"
    try:
        proc=subprocess.run([sys.executable,'-X','utf8','-c',payload],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=3)
        if proc.returncode:
            print(json.dumps({'error':(proc.stderr or proc.stdout)[-5000:]},ensure_ascii=False)); return 0
        rows=json.loads(proc.stdout)
        outrows=[{'ok':x[0],'input':x[1],'expected':x[2],'actual':x[3],'message':x[4]} for x in rows]
        print(json.dumps({'passed':sum(1 for x in outrows if x['ok']),'total':len(outrows),'results':outrows},ensure_ascii=False)); return 0
    except subprocess.TimeoutExpired:
        print(json.dumps({'error':'Time limit exceeded (3 seconds). Check for an infinite loop.'})); return 0
    except Exception:
        print(json.dumps({'error':traceback.format_exc()[-5000:]},ensure_ascii=False)); return 0

if __name__=='__main__':
    raise SystemExit(cli_main())
