const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
let panel;
let currentId = 0;
let currentChallenge = null;
let extensionContext;
let conceptCatalog = [];
let bankInfo = {bank_size:120000, pattern_count:0};

function workspaceRoot() {
  const folders = vscode.workspace.workspaceFolders;
  if (!folders || !folders.length) throw new Error('Open a folder in VS Code first (File → Open Folder).');
  return folders[0].uri.fsPath;
}
function labDir() { return path.join(workspaceRoot(), '.python-hero'); }
function enginePath() { return path.join(extensionContext.extensionPath, 'engine', 'challenge_engine.py'); }
function pythonPath() { return vscode.workspace.getConfiguration('pythonLab').get('pythonPath', 'python'); }
function runEngine(args, input='') {
  return new Promise((resolve, reject) => {
    cp.execFile(pythonPath(), [enginePath(), '--cli', ...args.map(String)], {cwd: workspaceRoot(), timeout: 10000, maxBuffer: 1024*1024, windowsHide: true}, (err, stdout, stderr) => {
      if (err && !stdout) return reject(new Error(stderr || err.message || 'Could not start Python. Check pythonLab.pythonPath.'));
      try { resolve(JSON.parse(stdout.trim())); } catch (e) { reject(new Error('Challenge engine returned invalid output. ' + (stderr || stdout).slice(-1000))); }
    }).stdin?.end(input);
  });
}
// Use spawn for stdin so long/multiline source is passed safely and not put on the command line.
function runEngineWithInput(args, input='') {
  return new Promise((resolve, reject) => {
    const child = cp.spawn(pythonPath(), [enginePath(), '--cli', ...args.map(String)], {cwd: workspaceRoot(), windowsHide: true});
    let out='', err=''; child.stdout.on('data',d=>out+=d); child.stderr.on('data',d=>err+=d);
    child.on('error',e=>reject(new Error(e.message + ' — check pythonLab.pythonPath.')));
    child.on('close',code=>{ try { resolve(JSON.parse(out.trim())); } catch(e) { reject(new Error(err || out || `Python exited with code ${code}`)); } });
    child.stdin.end(input);
  });
}
function progressPath() { return path.join(labDir(), 'progress.json'); }
function readProgress() { try { return JSON.parse(fs.readFileSync(progressPath(),'utf8')); } catch { return {current:0,passed:[],learned:[],attempts:0}; } }
function writeProgress(p) { fs.mkdirSync(labDir(),{recursive:true}); fs.writeFileSync(progressPath(),JSON.stringify(p,null,2),'utf8'); }
async function loadChallenge(id, openEditor=true) {
  currentId = Math.max(0, Math.min(119999, Number(id)||0));
  currentChallenge = await runEngine(['challenge', currentId]);
  const progress=readProgress(); progress.current=currentId; writeProgress(progress);
  if (panel) { panel.title = `Python Lab · ${currentId+1}`; panel.webview.html = html(currentChallenge,progress,conceptCatalog,bankInfo); }
  if (openEditor) await openChallengeFile(currentChallenge);
}
async function openChallengeFile(ch) {
  const dir=path.join(labDir(),'challenges'); fs.mkdirSync(dir,{recursive:true});
  const file=path.join(dir,`challenge_${String(ch.id+1).padStart(6,'0')}.py`);
  if (!fs.existsSync(file)) fs.writeFileSync(file, ch.pattern.starter + '\n','utf8');
  const doc=await vscode.workspace.openTextDocument(file); await vscode.window.showTextDocument(doc, vscode.ViewColumn.One);
}
function esc(s) { return String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function pretty(value) {
 try { return JSON.stringify(value, null, 2); } catch { return String(value); }
}
function html(ch,progress,catalog=[],info={bank_size:120000,pattern_count:0}) {
 const p=ch.pattern, passed=new Set(progress.passed||[]), learned=new Set(progress.learned||[]);
 const tests=(ch.cases||[]).map((input,i)=>`<tr><td>${i+1}</td><td><code>${esc(pretty(input))}</code></td><td><code>${esc(pretty((ch.expected_cases||[])[i]))}</code></td></tr>`).join('');
 const topics=[...new Set(catalog.map(x=>x.topic))].sort();
 const levels=[...new Set(catalog.map(x=>x.level||'Intermediate'))].sort();
 const topicOptions=topics.map(t=>`<option value="${esc(t)}">${esc(t)}</option>`).join('');
 const levelOptions=levels.map(t=>`<option value="${esc(t)}">${esc(t)}</option>`).join('');
 const catalogJson=JSON.stringify(catalog).replace(/</g,'\\u003c');
 const sentences=String(p.learn||'').split(/(?<=[.!?])\s+/).filter(Boolean);
 const learningSteps=sentences.map((line,i)=>`<li><strong>${i===0?'Understand the idea':i===1?'Apply it':'Remember'}</strong><div>${esc(line)}</div></li>`).join('');
 return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>
 :root{color-scheme:light dark}*{box-sizing:border-box}body{font-family:var(--vscode-font-family);padding:18px;color:var(--vscode-foreground);line-height:1.55;max-width:1050px;margin:auto;font-size:var(--vscode-font-size)}
 h1{font-size:24px;line-height:1.25;margin:5px 0 8px}h2{font-size:17px;margin:0 0 10px}h3{font-size:14px;margin:15px 0 5px}.muted{color:var(--vscode-descriptionForeground)}.eyebrow{font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--vscode-descriptionForeground)}
 .card{border:1px solid var(--vscode-panel-border);border-radius:10px;padding:16px;margin:14px 0;background:var(--vscode-editor-background)}.hero{border-left:4px solid var(--vscode-focusBorder)}.status{padding:10px 12px;border-radius:7px;background:var(--vscode-sideBar-background);margin:12px 0}.row{display:flex;flex-wrap:wrap;gap:6px;margin:12px 0}button{border:1px solid var(--vscode-button-border,transparent);background:var(--vscode-button-background);color:var(--vscode-button-foreground);padding:8px 11px;border-radius:5px;cursor:pointer;font:inherit}button:hover{filter:brightness(1.08)}button.secondary{background:var(--vscode-button-secondaryBackground);color:var(--vscode-button-secondaryForeground)}
 .searchbox{display:grid;grid-template-columns:minmax(120px,1fr) minmax(120px,.8fr);gap:8px;margin-top:10px}.searchbox input,.searchbox select{width:100%;padding:9px;border-radius:5px;border:1px solid var(--vscode-input-border);background:var(--vscode-input-background);color:var(--vscode-input-foreground);font:inherit}.search-results{max-height:230px;overflow:auto;border:1px solid var(--vscode-panel-border);border-radius:7px;margin-top:8px}.search-result{display:block;width:100%;text-align:left;border:0;border-radius:0;border-bottom:1px solid var(--vscode-panel-border);background:transparent;color:var(--vscode-foreground);padding:10px}.search-result:hover{background:var(--vscode-list-hoverBackground)}.search-result small{display:block;color:var(--vscode-descriptionForeground);margin-top:3px}.learn-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}.mini{padding:12px;border-radius:7px;background:var(--vscode-textBlockQuote-background);border:1px solid var(--vscode-panel-border)}.mini strong{display:block;margin-bottom:4px}.steps{padding-left:22px}.steps li{padding:5px 0 8px}.steps li::marker{color:var(--vscode-textLink-foreground);font-weight:700}.callout{padding:10px 12px;border-left:3px solid var(--vscode-textLink-foreground);background:var(--vscode-textBlockQuote-background);margin-top:10px}
 pre{white-space:pre-wrap;overflow-wrap:anywhere;background:var(--vscode-textCodeBlock-background);padding:12px;border-radius:6px;margin:6px 0}code{font-family:var(--vscode-editor-font-family,monospace);overflow-wrap:anywhere}.table-wrap{overflow-x:auto;border:1px solid var(--vscode-panel-border);border-radius:7px}table{width:100%;border-collapse:collapse;min-width:360px}th,td{text-align:left;padding:9px 10px;border-bottom:1px solid var(--vscode-panel-border);vertical-align:top}th{background:var(--vscode-sideBar-background);font-weight:700}tr:last-child td{border-bottom:0}.pill{display:inline-block;border:1px solid var(--vscode-panel-border);border-radius:99px;padding:2px 8px;font-size:12px;margin:2px}.test-title{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}.small{font-size:12px}.result{white-space:pre-wrap;overflow-wrap:anywhere}.resultline{padding:9px 0;border-bottom:1px solid var(--vscode-panel-border)}.resultline:last-child{border:0}.pass{color:var(--vscode-testing-iconPassed,#3fb950)}.fail{color:var(--vscode-testing-iconFailed,#f85149)}
 @media(max-width:520px){body{padding:10px}.card{padding:12px}h1{font-size:21px}}
 </style></head><body>
 <div class="eyebrow">Python Lab · Guided practice</div><h1>${esc(p.name)}</h1><div class="muted">Challenge ${ch.id+1} of ${ch.bank_size.toLocaleString()} · ${esc(p.topic)}</div>
 <section class="card"><div class="eyebrow">Find a concept</div><h2>Search and filter challenges</h2><p class="muted">Search by concept, method, topic, or task. Choose a result to open a matching challenge.</p><div class="searchbox"><input id="conceptSearch" type="search" placeholder="Search real-world tasks, APIs, parsing, data…" aria-label="Search concepts"><select id="topicFilter" aria-label="Filter by topic"><option value="">All topics</option>${topicOptions}</select><select id="levelFilter" aria-label="Filter by difficulty"><option value="">All levels</option>${levelOptions}</select></div><div class="muted small" id="searchCount"></div><div class="search-results" id="searchResults" role="list"></div><p class="muted small">Scale: ${Number(info.bank_size||1000000).toLocaleString()} generated challenge instances from ${Number(info.pattern_count||catalog.length).toLocaleString()} scenario templates. These are parameterized variants, not a million individually authored problems. Search lists the distinct core challenge concepts; each can have many input variations.</p></section>
 <div class="status"><strong>Progress</strong> &nbsp; <span class="pill">${passed.size.toLocaleString()} passed</span><span class="pill">${learned.size.toLocaleString()} learned</span><span class="pill">${progress.attempts||0} total checks</span></div>
 <div class="row"><button data-cmd="previous">← Previous</button><button data-cmd="next">Next →</button><button data-cmd="random">Random challenge</button><button class="secondary" data-cmd="hint">Show hint</button><button class="secondary" data-cmd="solution">Worked solution</button></div>
 <details class="card hero"><summary><strong>Optional guide · ${esc(p.concept)}</strong> <span class="muted">Open only when you need help</span></summary><div style="padding-top:12px"><h2>${esc(p.concept)}</h2><div class="learn-grid"><div class="mini"><strong>What you are learning</strong>${esc(p.concept)}<div class="muted small" style="margin-top:5px">Topic: ${esc(p.topic)}</div></div><div class="mini"><strong>Why it matters</strong>${esc(p.why)}</div></div><h3>Concept explained in small steps</h3><ol class="steps">${learningSteps}</ol><div class="callout"><strong>Goal:</strong> Try independently first. Open this guide only when you need it. Your function should return the answer; do not use print unless the challenge asks for it.</div><h3>Python field guide</h3><p>For collections, choose a list for ordered mutable data, a tuple for fixed records, a set for uniqueness/membership, and a dictionary for key-value lookup. For robust production code, validate inputs at boundaries, handle expected exceptions narrowly, avoid mutating caller-owned data unless documented, and make ordering/tie-breakers explicit.</p><p>For performance, prefer one-pass dictionaries/sets for aggregation and membership, sorting when deterministic ranking is needed, generators for streaming, and a sliding window/running sum for moving aggregates. Measure before optimizing; document complexity in terms of input size.</p><p>For reliability, test empty inputs, single items, duplicates, invalid values, boundary values, and large inputs. Keep functions deterministic and separate parsing, validation, business logic, and I/O.</p></div></details>
 <section class="card"><div class="eyebrow">Step 2 · Understand the task</div><h2>Your challenge</h2><p>${esc(p.prompt)}</p><h3>Starter code</h3><pre>${esc(p.starter)}</pre><h3>Example input</h3><pre>${esc(pretty(ch.arg))}</pre><p class="muted small">The challenge file opens in the VS Code editor. Replace the placeholder code with your solution, then save it.</p></section>
 <section class="card"><div class="test-title"><div><div class="eyebrow">Step 3 · Know how your answer is tested</div><h2>Test cases and expected results</h2></div><span class="pill">${(ch.cases||[]).length} visible cases</span></div><p>Each row shows an input and the correct expected result. Your solution must match all cases. These examples help you understand normal, boundary, and varied inputs; passing these does not guarantee every possible input.</p><div class="table-wrap"><table><thead><tr><th style="width:44px">#</th><th>Input</th><th>Expected result</th></tr></thead><tbody>${tests}</tbody></table></div></section>
 <section class="card"><div class="eyebrow">Step 4 · Practise and verify</div><h2>Run your code or check all tests</h2><p><strong>Run &amp; check all tests</strong> saves your current file and checks every listed case automatically. Results show each PASS/FAIL, input, expected output, actual output, and any error. <strong>Run example only</strong> is optional.</p><div class="row"><button data-cmd="check">▶ Run &amp; check all ${(ch.cases||[]).length} tests</button><button class="secondary" data-cmd="run">Run example only</button><button class="secondary" data-cmd="markLearned">Mark concept learned</button></div><div id="result" class="card result" hidden aria-live="polite"></div><div id="tip" class="card result" hidden aria-live="polite"></div></section>
 <script>const vscode=acquireVsCodeApi();const catalog=${catalogJson};document.querySelectorAll('button[data-cmd]').forEach(b=>b.addEventListener('click',()=>vscode.postMessage({command:b.dataset.cmd})));const search=document.getElementById('conceptSearch'),topic=document.getElementById('topicFilter'),level=document.getElementById('levelFilter'),results=document.getElementById('searchResults'),count=document.getElementById('searchCount');function renderSearch(){const q=(search.value||'').trim().toLowerCase(),t=topic.value,l=level.value;const found=catalog.filter(x=>(!t||x.topic===t)&&(!l||(x.level||'Intermediate')===l)&&(!q||(x.keywords||'').toLowerCase().includes(q))).slice(0,100);count.textContent=found.length+' matching concepts'+(found.length===100?' (showing first 100)':'');results.replaceChildren();if(!found.length){const empty=document.createElement('div');empty.className='search-result';empty.textContent='No matching concepts. Try a broader keyword or All topics.';results.appendChild(empty);return;}for(const x of found){const b=document.createElement('button');b.className='search-result';b.innerHTML='<strong></strong><small></small>';b.querySelector('strong').textContent=x.name;b.querySelector('small').textContent=x.topic+' · '+x.concept;b.addEventListener('click',()=>vscode.postMessage({command:'openConcept',id:x.id}));results.appendChild(b);}}search.addEventListener('input',renderSearch);topic.addEventListener('change',renderSearch);level.addEventListener('change',renderSearch);renderSearch();window.addEventListener('message',e=>{const m=e.data;if(m.kind==='progress'){const el=document.querySelector('.status');if(el)el.innerHTML='<strong>Progress</strong> &nbsp; <span class="pill">'+m.text.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</span>';return;}const el=document.getElementById(m.kind==='tip'?'tip':'result');el.hidden=false;el.textContent=m.text;el.scrollIntoView({behavior:'smooth',block:'nearest'});});</script></body></html>`;
}
async function activeSource() {
  // Webview buttons take focus away from the text editor, so never depend on activeTextEditor.
  // Resolve the exact file for the selected challenge and read its live VS Code document.
  if(!currentChallenge) throw new Error('No challenge is selected. Open Python Lab: Open Challenge Lab first.');
  const file=path.join(labDir(),'challenges',`challenge_${String(currentChallenge.id+1).padStart(6,'0')}.py`);
  if(!fs.existsSync(file)) await openChallengeFile(currentChallenge);
  const doc=await vscode.workspace.openTextDocument(file);
  const editor=vscode.window.visibleTextEditors.find(e=>e.document.uri.fsPath.toLowerCase()===file.toLowerCase());
  if(editor && editor.document.isDirty) await editor.document.save();
  else if(doc.isDirty) await doc.save();
  return {source:doc.getText(),file};
}
async function runOrCheck(checking) {
 try {
  if(!currentChallenge) await loadChallenge(readProgress().current||0,false);
  const {source,file}=await activeSource();
  const match=path.basename(file).match(/^challenge_(\d+)\.py$/);
  if(!match) throw new Error('The selected challenge file could not be identified. Use Previous/Next in the Python Lab panel.');
  if(Number(match[1])-1!==currentId) { await loadChallenge(Number(match[1])-1,false); return runOrCheck(checking); }
  const ch=currentChallenge;
  const res=await runEngineWithInput([checking?'check':'run',ch.id],source);
  if(checking) {
   if(res.error) { showMessage('result',res.error); return; }
   const progress=readProgress(); progress.attempts=(progress.attempts||0)+1;
   const lines=[`TEST RESULTS: ${res.passed}/${res.total} passed`,res.passed===res.total?'All listed test cases passed.':'Review each failing case below.',''];
   (res.results||[]).forEach((r,i)=>lines.push(`${r.ok?'PASS':'FAIL'} · Test ${i+1}\n  Input: ${r.input}\n  Expected: ${r.expected}\n  Actual: ${r.actual}${r.ok?'':'\n  Error: '+r.message}`));
   if(res.passed===res.total) { const s=new Set(progress.passed||[]);s.add(ch.id);progress.passed=[...s].sort((a,b)=>a-b); lines.unshift('🎉 All tests passed!'); }
   writeProgress(progress); showMessage('result',lines.join('\n')); showMessage('progress',`${(progress.passed||[]).length} passed · ${(progress.learned||[]).length} learned · ${progress.attempts} total checks`);
   vscode.window.showInformationMessage(`Python Lab: ${res.passed}/${res.total} tests passed.`);
  } else {
   const out=[res.stdout||'',res.stderr||''].filter(Boolean).join('\n') || '(No output)'; showMessage('result',(res.returncode===0?'Output:\n':'Error:\n')+out);
  }
 } catch(e) { vscode.window.showErrorMessage(e.message); }
}
function showMessage(kind,text) { if(panel) panel.webview.postMessage({kind,text}); else vscode.window.showInformationMessage(text.slice(0,300)); }
async function showHint() { try {const x=await runEngine(['hint',currentId]);showMessage('tip','HINT\n'+x.hint);}catch(e){vscode.window.showErrorMessage(e.message);} }
async function showSolution() { try {const x=await runEngine(['solution',currentId]);const doc=await vscode.workspace.openTextDocument({language:'python',content:'# Worked solution — study this, then try again.\n\n'+x.solution+'\n'});await vscode.window.showTextDocument(doc,vscode.ViewColumn.Beside,{preview:true});}catch(e){vscode.window.showErrorMessage(e.message);} }
async function markLearned() {const p=readProgress();const s=new Set(p.learned||[]);s.add(currentId);p.learned=[...s].sort((a,b)=>a-b);writeProgress(p);if(panel)panel.webview.html=html(currentChallenge,p,conceptCatalog,bankInfo);vscode.window.showInformationMessage('Challenge marked as learned.');}
function activate(context) {
 extensionContext=context;
 const reg=(id,fn)=>context.subscriptions.push(vscode.commands.registerCommand(id,fn));
 reg('pythonLab.openChallenge',async()=>{try{workspaceRoot();if(!conceptCatalog.length){const cat=await runEngine(['catalog']);conceptCatalog=cat.patterns||[];bankInfo={bank_size:cat.bank_size||120000,pattern_count:cat.pattern_count||conceptCatalog.length};}if(!panel){panel=vscode.window.createWebviewPanel('pythonLabLab','Python Lab',vscode.ViewColumn.Beside,{enableScripts:true,retainContextWhenHidden:true});panel.onDidDispose(()=>panel=undefined);panel.webview.onDidReceiveMessage(async m=>{if(m.command==='openConcept')await loadChallenge(Number(m.id)||0);else if(m.command==='previous')await loadChallenge(currentId-1);else if(m.command==='next')await loadChallenge(currentId+1);else if(m.command==='random')await loadChallenge(Math.floor(Math.random()*120000));else if(m.command==='hint')await showHint();else if(m.command==='solution')await showSolution();else if(m.command==='run')await runOrCheck(false);else if(m.command==='check')await runOrCheck(true);else if(m.command==='markLearned')await markLearned();});}await loadChallenge(readProgress().current||0);}catch(e){vscode.window.showErrorMessage(e.message);}});
 reg('pythonLab.previous',()=>loadChallenge(currentId-1)); reg('pythonLab.next',()=>loadChallenge(currentId+1)); reg('pythonLab.random',()=>loadChallenge(Math.floor(Math.random()*120000))); reg('pythonLab.run',()=>runOrCheck(false)); reg('pythonLab.check',()=>runOrCheck(true)); reg('pythonLab.hint',showHint); reg('pythonLab.solution',showSolution); reg('pythonLab.markLearned',markLearned);
}
function deactivate() {}
module.exports={activate,deactivate};
