# Python Lab — 

A VS Code side-panel lab aimed at learners who have finished introductory syntax and want practical, intermediate/advanced Python exercises. The real Python editor remains native VS Code, so Python extension features such as indentation, IntelliSense, linting, debugging and formatting remain available when installed/configured.

## What changed in 

- The practice sequence now focuses on applied scenarios rather than beginner syntax drills: retry/backoff planning, log aggregation, event deduplication, CSV/data validation, slow endpoint metrics, interval conflicts, layered configuration, batching, duration parsing, and rolling averages.
- Search concepts directly in the right panel, filter by topic and difficulty, and click a result to open it.
- Learning material is collapsed under **Optional guide**. Try the task first; open the guide only when you choose.
- Hints and worked solutions remain available on demand.
- **Run & check all tests** saves the selected challenge file and reports every test's input, expected result, actual result, and error.
- Progress is stored in `.python-hero/progress.json`; challenge files remain under `.python-hero/challenges`.

## About the million-scale bank

The lab exposes 1,000,000 parameterized challenge instances, generated from 10 applied scenario templates with deterministic input variation. This is **not** one million individually authored unique questions. The visible catalog shows the 10 distinct scenario templates. More templates should be added only with reference implementations and test validation; inflating a count with duplicate wording would not be useful practice.

## Install on Windows

1. In VS Code, open Extensions (`Ctrl+Shift+X`), search for **Python Lab**, and uninstall the old version.
2. Reload VS Code using `Ctrl+Shift+P` → `Developer: Reload Window`.
3. Keep your workspace's `.python-hero` folder to preserve progress and existing challenge files. Back it up before removing anything.
4. Open Extensions → `...` → **Install from VSIX...** and select `Python_Lab.vsix`.
5. Reload the window, open a workspace folder, then run `Python Lab: Open Challenge Lab` from the Command Palette.
6. Install Microsoft's Python extension and ensure the configured interpreter runs. If needed, set `pythonLab.pythonPath` to the full path of `python.exe`.

## Safety and verification

The checker executes submitted code as a local Python subprocess with a short timeout. It is not a security sandbox; do not run untrusted code. Engine syntax was checked and all 10 applied scenario reference solutions passed their six generated tests in the build environment. The extension has not been interactively tested inside your specific Windows VS Code installation.
